# Desktop UI (placeholder)

This folder is a placeholder for a desktop shell (Tauri/Electron).
For now, use `cmd/vaultctl` to exercise the core.

If you expose a gRPC/HTTP API from the core, place `.proto` schemas under `./protos`.
