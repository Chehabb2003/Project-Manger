package sync

// TODO: implement a simple Noise/X3DH-like relay channel for device-to-device messages
